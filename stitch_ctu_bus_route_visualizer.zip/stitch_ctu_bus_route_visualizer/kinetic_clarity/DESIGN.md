---
name: Kinetic Clarity
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#4648d4'
  on-secondary: '#ffffff'
  secondary-container: '#6063ee'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#40000d'
  on-tertiary-container: '#f23d5c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  max-width: 1280px
---

## Brand & Style

This design system is built for high-performance environments where speed of thought meets precision of action. The brand personality is **technical, focused, and forward-leaning**, targeting users who value efficiency and depth over superficial flair. 

The visual style is a fusion of **Minimalism** and **Modern Corporate**, utilizing heavy whitespace to reduce cognitive load while maintaining a disciplined, systematic structure. The emotional response should be one of "effortless mastery"—a sense that the tool is an extension of the user's professional intent. Design elements are stripped of decorative noise, relying on superior typography and a rigorous grid to establish authority.

## Colors

The palette is anchored by a high-contrast foundation of absolute black and crisp white, ensuring maximum legibility and a classic professional aesthetic.

- **Primary:** A deep, authoritative black used for typography, primary actions, and structural boundaries.
- **Secondary:** A vibrant indigo used sparingly for interactive highlights, active states, and focus indicators.
- **Tertiary:** A sharp rose/red reserved exclusively for destructive actions or critical system alerts.
- **Neutral:** A range of cool grays starting from a soft off-white background to define subtle surface transitions and secondary information hierarchies.

The default state is a light, airy canvas that prioritizes clarity, though the system is architected to invert seamlessly into a high-contrast dark mode for late-night focused work.

## Typography

This design system employs a tri-font strategy to balance impact, readability, and technical precision.

- **Headlines:** Uses **Hanken Grotesk** for a sharp, contemporary feel. Tight letter-spacing and bold weights communicate confidence in large formats.
- **Body:** Uses **Inter** for its unparalleled legibility and neutral tone. It handles dense information effortlessly across all screen sizes.
- **Data & Labels:** Uses **JetBrains Mono** for metadata, labels, and code snippets. The monospaced nature emphasizes the technical accuracy of the underlying data.

Scaling is handled via a modular scale. For mobile, display and large headline sizes are reduced to ensure they remain within the viewport without excessive wrapping.

## Layout & Spacing

The layout philosophy is based on a **fixed-fluid hybrid grid**. Content is contained within a 1280px max-width container on desktop, centered with generous outer margins to focus the eye.

- **Grid:** A 12-column system is used for desktop (64px margins, 24px gutters), collapsing to 4 columns for mobile (16px margins, 16px gutters).
- **Rhythm:** An 8px linear scale (with 4px sub-steps) governs all spatial relationships. Every component's height and padding must be a multiple of 4px.
- **Responsive Behavior:** Elements should prioritize vertical stacking on mobile. On tablet and desktop, use "Surface Containers" to group related content, allowing the grid to dictate width while maintaining consistent internal padding.

## Elevation & Depth

This system rejects heavy shadows in favor of **Tonal Layers** and **Low-Contrast Outlines**. 

Depth is communicated through background color shifts:
1. **Level 0 (Base):** The main canvas background (`#f8fafc`).
2. **Level 1 (Surface):** White cards or containers that sit on top of the base.
3. **Level 2 (Overlay):** Used for modals or menus, utilizing a very subtle, diffused shadow (0px 4px 20px rgba(0,0,0,0.05)) to separate from the surface.

Separation is primarily achieved through 1px solid borders in a light neutral gray. This "ghost border" technique keeps the UI flat and professional, avoiding the visual clutter of neomorphism or heavy skeuomorphism.

## Shapes

The shape language is **Soft**. A consistent 4px (0.25rem) corner radius is applied to standard UI components like buttons, input fields, and chips. 

- **Small elements:** 4px radius (e.g., Checkboxes, tooltips).
- **Medium elements:** 8px radius (e.g., Cards, modals).
- **Interactive areas:** Never use fully rounded "pills" unless for status indicators (chips) to maintain the systematic, professional grid feel.

This subtle rounding softens the technical edge of the typography without losing the sense of architectural structure.

## Components

### Buttons
Primary buttons are solid black with white text. Secondary buttons use a 1px black outline with no fill. Hover states involve a slight background shift (e.g., black becomes a dark charcoal). Text within buttons should use the **Label** style for a technical feel.

### Input Fields
Fields consist of a 1px neutral border that turns into a 2px indigo border upon focus. Labels sit strictly above the input area using the monospaced font at a small scale.

### Chips & Tags
Used for categorization. These use the **Label-sm** typography. Status-specific chips (e.g., "Active", "Error") use a low-opacity tint of the secondary or tertiary colors with high-saturation text.

### Cards
Cards are white with a 1px border. No shadows should be used for static cards; a subtle shadow is only introduced when the card is interactive and in a "hover" state to indicate lift.

### Lists & Tables
Data density is a priority. Lists use subtle 1px dividers. Tables should have "sticky" headers and use alternating row highlights (zebra striping) only when data exceeds 10 columns.

### Checkboxes & Radios
Square-ish with a 2px radius. When checked, they fill with the primary black color and a white checkmark icon. This maintains the high-contrast aesthetic.